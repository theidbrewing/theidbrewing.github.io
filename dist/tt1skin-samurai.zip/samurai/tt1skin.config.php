<?php 
if ( ! defined( 'TT1_SKIN_NAME' ) ) :
    define( 'TT1_SKIN_NAME', 'samurai'  );
endif;

