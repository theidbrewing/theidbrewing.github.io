<?php
/**
 * ブロックパターンのカスタマイズ関連クラス.
 *
 * @since      0.0.1
 *
 * @package tt1skin
 */

if ( ! class_exists( 'TT1skin_Block_Pattern' ) ) {
	/**
	 * Msm Blocks
	 */
	class TT1skin_Block_Pattern {
		/**
		 * construct
		 */
		public static function init() {
			// 独自カテゴリーを追加.
			add_action( 'init', array( get_called_class(), 'register_block_pattern_category' ) );
			// 独自パターンを追加.
			add_action( 'init', array( get_called_class(), 'register_block_patterns' ) );
		}

		/**
		 * Register custom block pattern category
		 */
		public static function register_block_pattern_category() {
			register_block_pattern_category(
				__( 'tt1skin', 'tt1skin' ),
				array( 'label' => 'TT1skin' )
			);
		}

		/**
		 * Register custom block pattern
		 */
		public static function register_block_patterns() {
			$skin_data = TT1skin_Skin_Data::get_instance()->get_skin_data();
			if ( ! is_array( $skin_data ) ) {
				return;
			}
			if ( ! array_key_exists( 'block_pattern', $skin_data ) || ! is_array( $skin_data['block_pattern'] ) ) {
				return;
			}
			foreach ( $skin_data['block_pattern'] as $pattern ) {
				if ( ! file_exists( TT1SKIN_PATH . '/src/skins/' . $skin_data['name'] . '/block_pattern/' . $pattern . '.json' ) ) {
					continue;
				}
				register_block_pattern(
					"tt1skin/{$pattern}",
					TT1skin_Json_Controller::get_json_data( TT1SKIN_PATH . '/src/skins/' . $skin_data['name'] . "/block_pattern/{$pattern}.json" )
				);
			}
		}
	}
}
