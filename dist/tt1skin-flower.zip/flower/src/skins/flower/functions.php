<?php
/**
 * Functions for flower skin
 *
 * The file that defines the core plugin class
 *
 * @package tt1skin
 */

add_filter( 'privacy_policy_url', '__return_empty_string' );